-- MySQL dump 10.13  Distrib 5.7.40, for Linux (aarch64)
--
-- Host: localhost    Database: GPIO
-- ------------------------------------------------------
-- Server version	5.7.40-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `GPIO_PIN_C2_K516er`
--

DROP TABLE IF EXISTS `GPIO_PIN_C2_K516er`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GPIO_PIN_C2_K516er` (
  `UniqueID` int(2) NOT NULL,
  `INOUT` varchar(6) NOT NULL,
  `Purpose` varchar(20) NOT NULL,
  `LEDNr` int(1) NOT NULL,
  `Color` varchar(6) NOT NULL,
  `OdroidJ2` int(2) NOT NULL,
  `wPi` int(2) NOT NULL,
  `I/O` varchar(5) NOT NULL,
  `sysfs` int(3) NOT NULL,
  `GPIO_bank` varchar(9) NOT NULL,
  `GPIOD` int(3) NOT NULL,
  PRIMARY KEY (`UniqueID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GPIO_PIN_C2_K516er`
--

LOCK TABLES `GPIO_PIN_C2_K516er` WRITE;
/*!40000 ALTER TABLE `GPIO_PIN_C2_K516er` DISABLE KEYS */;
INSERT INTO `GPIO_PIN_C2_K516er` (`UniqueID`, `INOUT`, `Purpose`, `LEDNr`, `Color`, `OdroidJ2`, `wPi`, `I/O`, `sysfs`, `GPIO_bank`, `GPIOD`) VALUES (1,'IN','Tacho',1,'green',7,7,'491',249,'gpiochip1',113),(2,'IN','Brake',2,'green',11,0,'489',247,'gpiochip1',111),(3,'IN','ABS',3,'green',13,2,'481',239,'gpiochip1',103),(4,'IN','Clutch',4,'green',15,3,'479',237,'gpiochip1',101),(5,'IN','',5,'green',12,1,'480',238,'gpiochip1',102),(6,'IN','',6,'green',16,4,'478',236,'gpiochip1',100),(7,'IN','',7,'green',18,5,'475',233,'gpiochip1',97),(8,'IN','Ignition',8,'green',22,6,'473',231,'gpiochip1',95),(9,'OUT','Heartbeat',1,'yellow',33,23,'476',234,'gpiochip1',98),(10,'OUT','',2,'yellow',19,12,'477',235,'gpiochip1',99),(11,'OUT','',3,'yellow',24,10,'471',229,'gpiochip1',93),(12,'OUT','',4,'yellow',26,11,'467',225,'gpiochip1',89),(13,'OUT','',5,'yellow',21,13,'474',232,'gpiochip1',96),(14,'OUT','',6,'yellow',23,14,'472',230,'gpiochip1',94),(15,'OUT','',7,'yellow',29,21,'470',228,'gpiochip1',92),(16,'OUT','',8,'yellow',31,22,'461',219,'gpiochip1',83),(17,'UNUSED','',0,'',32,26,'466',224,'gpiochip1',88),(18,'UNUSED','',0,'',35,24,'456',214,'gpiochip1',78),(19,'UNUSED','',0,'',36,27,'460',218,'gpiochip1',82),(20,'AIN0','',0,'blue',40,0,'1_raw',0,'',0),(21,'AIN1','',0,'blue',37,1,'0_raw',0,'',0);
/*!40000 ALTER TABLE `GPIO_PIN_C2_K516er` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GPIO_PIN_C4_K518er`
--

DROP TABLE IF EXISTS `GPIO_PIN_C4_K518er`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GPIO_PIN_C4_K518er` (
  `UniqueID` int(2) NOT NULL,
  `INOUT` varchar(6) NOT NULL,
  `Purpose` varchar(20) NOT NULL,
  `LEDNr` int(1) NOT NULL,
  `Color` varchar(6) NOT NULL,
  `OdroidJ2` int(2) NOT NULL,
  `wPi` int(2) NOT NULL,
  `I/O` varchar(5) NOT NULL,
  `sysfs` int(3) NOT NULL,
  `GPIO_bank` varchar(9) NOT NULL,
  `GPIOD` int(3) NOT NULL,
  PRIMARY KEY (`UniqueID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GPIO_PIN_C4_K518er`
--

LOCK TABLES `GPIO_PIN_C4_K518er` WRITE;
/*!40000 ALTER TABLE `GPIO_PIN_C4_K518er` DISABLE KEYS */;
INSERT INTO `GPIO_PIN_C4_K518er` (`UniqueID`, `INOUT`, `Purpose`, `LEDNr`, `Color`, `OdroidJ2`, `wPi`, `I/O`, `sysfs`, `GPIO_bank`, `GPIOD`) VALUES (1,'IN','Tacho',1,'green',7,7,'497',249,'gpiochip0',70),(2,'IN','Brake',2,'green',11,0,'495',247,'gpiochip0',68),(3,'IN','ABS',3,'green',13,2,'496',239,'gpiochip0',69),(4,'IN','Clutch',4,'green',15,3,'499',237,'gpiochip0',72),(5,'IN','',5,'green',12,1,'508',238,'gpiochip0',81),(6,'IN','',6,'green',16,4,'492',236,'gpiochip0',65),(7,'IN','',7,'green',18,5,'493',233,'gpiochip0',66),(8,'IN','Ignition',8,'green',22,6,'494',231,'gpiochip0',67),(9,'OUT','Heartbeat',1,'yellow',33,23,'498',234,'gpiochip0',71),(10,'OUT','',2,'yellow',19,12,'500',235,'gpiochip0',73),(11,'OUT','',3,'yellow',24,10,'502',229,'gpiochip0',75),(12,'OUT','',4,'yellow',26,11,'449',225,'gpiochip0',22),(13,'OUT','',5,'yellow',21,13,'501',232,'gpiochip0',74),(14,'OUT','',6,'yellow',23,14,'503',230,'gpiochip0',76),(15,'OUT','',7,'yellow',29,21,'506',228,'gpiochip0',79),(16,'OUT','',8,'yellow',31,22,'507',219,'gpiochip0',80),(17,'UNUSED','',0,'',32,26,'450',224,'gpiochip0',23),(18,'UNUSED','',0,'',35,24,'511',214,'gpiochip0',84),(19,'UNUSED','',0,'',36,27,'448',218,'gpiochip0',21),(20,'AIN.2','',0,'blue',37,25,'2_raw',0,'',0),(21,'AIN.0','',0,'blue',40,29,'0_raw',0,'',0);
/*!40000 ALTER TABLE `GPIO_PIN_C4_K518er` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'GPIO'
--

--
-- Dumping routines for database 'GPIO'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-28 22:58:56
