-- MySQL dump 10.13  Distrib 5.7.37, for Linux (aarch64)
--
-- Host: localhost    Database: GPIO
-- ------------------------------------------------------
-- Server version	5.7.37-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `GPIO_PIN`
--

DROP TABLE IF EXISTS `GPIO_PIN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GPIO_PIN` (
  `UniqueID` int(2) NOT NULL,
  `INOUT` varchar(6) NOT NULL,
  `Purpose` varchar(20) NOT NULL,
  `LEDNr` int(1) DEFAULT NULL,
  `Color` varchar(6) NOT NULL,
  `OdroidJ2` int(2) NOT NULL,
  `wPi` varchar(4) NOT NULL,
  `wPi_GPIOD` int(2) DEFAULT NULL,
  `I/O` varchar(5) NOT NULL,
  `sysfs` int(3) NOT NULL,
  `GPIO_bank` varchar(9) NOT NULL,
  `GPIOD` int(3) DEFAULT NULL,
  PRIMARY KEY (`UniqueID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GPIO_PIN`
--

LOCK TABLES `GPIO_PIN` WRITE;
/*!40000 ALTER TABLE `GPIO_PIN` DISABLE KEYS */;
INSERT INTO `GPIO_PIN` (`UniqueID`, `INOUT`, `Purpose`, `LEDNr`, `Color`, `OdroidJ2`, `wPi`, `wPi_GPIOD`, `I/O`, `sysfs`, `GPIO_bank`, `GPIOD`) VALUES (1,'IN','Tacho',1,'green',7,'7',11,'491',249,'gpiochip1',113),(2,'IN','Brake',2,'green',11,'0',2,'489',247,'gpiochip1',111),(3,'IN','ABS',3,'green',13,'2',23,'481',239,'gpiochip1',103),(4,'IN','Clutch',4,'green',15,'3',13,'479',237,'gpiochip1',101),(5,'IN','',5,'green',12,'1',12,'480',238,'gpiochip1',102),(6,'IN','',6,'green',16,'4',14,'478',236,'gpiochip1',100),(7,'IN','',7,'green',18,'5',5,'475',233,'gpiochip1',97),(8,'IN','Ignition',8,'green',22,'6',22,'473',231,'gpiochip1',95),(9,'OUT','Heartbeat',1,'yellow',33,'23',6,'476',234,'gpiochip1',98),(10,'OUT','',2,'yellow',19,'12',4,'477',235,'gpiochip1',99),(11,'OUT','',3,'yellow',24,'10',27,'471',229,'gpiochip1',93),(12,'OUT','',4,'yellow',26,'11',0,'467',225,'gpiochip1',89),(13,'OUT','',5,'yellow',21,'13',21,'474',232,'gpiochip1',96),(14,'OUT','',6,'yellow',23,'14',26,'472',230,'gpiochip1',94),(15,'OUT','',7,'yellow',29,'21',24,'470',228,'gpiochip1',92),(16,'OUT','',8,'yellow',31,'22',0,'461',219,'gpiochip1',83),(17,'UNUSED','',NULL,'',32,'26',NULL,'466',224,'gpiochip1',88),(18,'UNUSED','',NULL,'',35,'24',7,'456',214,'gpiochip1',78),(19,'UNUSED','',NULL,'',36,'27',1,'460',218,'gpiochip1',82),(20,'AIN0','',NULL,'',40,'AIN0',NULL,'1_raw',0,'gpiochip1',NULL),(21,'AIN1','',NULL,'',37,'AIN1',NULL,'0_raw',0,'gpiochip1',NULL);
/*!40000 ALTER TABLE `GPIO_PIN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'GPIO'
--

--
-- Dumping routines for database 'GPIO'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-03 11:57:47
